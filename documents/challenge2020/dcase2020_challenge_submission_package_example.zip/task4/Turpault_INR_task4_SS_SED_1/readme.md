**Only the csv files formatted as `Turpault_INR_task4_SS_SED_1.output.tsv` are mandatory to participate.**

If you want your system to be evaluated in terms of SS metrics as well please submit a file formatted as `Turpault_INR_task4_SS_SED_1.ssmetrics.csv` that can be obtained from  https://github.com/google-research/sound-separation/blob/master/models/dcase2020_fuss_baseline/evaluate.py.

PSDS submissions are optional. If you want your system to be evaluated in PSDS please follow strictly the format illustrated in `Turpault_INR_task4_SS_SED_1.output_PSDS`. In order to comply with the submission platform restrictions, you will need to upload these in separate archive files.

If you experience any problem while submitting PSDS outputs please contact the task organizers (Romain Serizel in priority).
