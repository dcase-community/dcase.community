Participants are allowed to submit up to 4 different systems without ensembling and 4 systems with ensembling. Participants **have to submit at least one system without ensembling**. Participants using external data/pretrained models, please make sure to fill the field corresponding to the field in the yaml file.

For each submission, participants should provide the outputs obtained with 3 differents runs of the same systems in order to compute confidence intervals.

Please follow strictly the format illustrated in `Cornell_CMU_task4_1` directory.
**Before submission, please make sure you check that your submission package is correct with the validation script enclosed:**
```bash
python validate_submissions.py -i /Users/cornell/dcase2024/task4
```

In order to comply with the submission platform restrictions, you might need to split a zip file into multiple segments like so:
```bash
zip submission.zip --out split.zip -s 98m
```
which generates split.zip, split.z01, split.z02, ... all of which need to be uploaded.

Make sure that submission can actually be reconstructed from the split files like so:
```bash
zip -s 0 split.zip --out submission.zip
unzip submission.zip
```

If you experience any problem during submission please contact the task organizers (Romain Serizel in priority).
